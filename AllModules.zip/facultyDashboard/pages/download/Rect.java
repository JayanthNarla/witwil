class Rect
 {
   void fn1()
     {
        System.out.println("Fn1");
     }
    void fn2()
     {
       System.out.println("Fn2");
     }
     public static void main(String args[])
     {
      Rect S=new Rect();
      S.fn1();
      S.fn2();
}
}